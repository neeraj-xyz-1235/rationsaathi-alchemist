# RationSaathi frontend — household-first workflow

This frontend revision introduces a household setup gate, eligibility-proof upload UI, a backend-driven entitlement page, a withdrawal/receipt workflow, and a real-data monthly calendar.

## Run the frontend

```bash
cd frontend
npm install
npm run dev
```

Vite proxies `/api` to `http://127.0.0.1:8000`.

## User journey

1. Public landing page.
2. Sign up or log in.
3. Authenticated users without a saved household profile are sent to `/setup`.
4. Complete head-of-household details, household members, state/district, ration scheme/category, and card colour; upload eligibility proof.
5. The eligibility service verifies the proof. Allocation is locked while proof is pending.
6. `/check` asks the backend to calculate the current monthly allocation from verified scheme rules. It does not let the user choose the official rice/wheat quantity.
7. `/withdrawals` records partial withdrawals against the current allocation and displays the server-generated receipt reference.
8. `/tracker` renders a calendar based on actual withdrawal records returned by the backend.
9. Reports, complaints, shops, and notifications need their respective persisted API endpoints before they can be treated as production-complete.

## Backend endpoints this UI expects

The existing auth endpoints remain `/api/auth/login`, `/api/auth/signup`, `/api/auth/me`, and `/api/auth/logout`.

Household and proof:
- `GET /api/household/profile` — return profile, `is_complete`, and `proof_status`.
- `PUT /api/household/profile` or `POST /api/household/profile` — create/update household profile.
- `POST /api/household/proof` — accept multipart form data (`file`, `document_type`) and return a proof status.

Entitlement:
- `GET /api/entitlements/current` — return the current verified allocation, period, scheme, status, and `items` containing item name, quantity, and unit.
- `POST /api/entitlements/allocate` — apply official state/scheme rules using verified profile data; the browser sends no requested entitlement quantity.

Withdrawals and receipt verification:
- `GET /api/withdrawals?month=YYYY-MM` — return persisted records for the month.
- `POST /api/withdrawals` — validate the remaining allocation server-side, persist a withdrawal, and return a receipt ID/reference and verification code.
- `GET /api/receipts/verify/{code}` — verify a receipt and return its validity/status.

**Security:** any third-party receipt/proof verification API key must be stored and used only by the backend (environment variable/secret manager). Never put a secret API key in React, Vite environment variables prefixed with `VITE_`, or browser requests. The backend must validate all quantities and balances; frontend checks are for usability only.

## Important domain rule

Ration-card colour is not a universal entitlement formula. Card colours, categories, and allocation rules vary by state and scheme. This UI collects the colour as supporting information but deliberately relies on the backend's verified scheme/category and official rules to determine monthly entitlement. Eligibility documents should be uploaded only to a secured backend with appropriate access controls, retention policy, and audit logging.

## Current integration status

The new pages call the endpoint contracts listed above. The frontend archive does not contain the FastAPI backend, and the household/proof/entitlement/withdrawal routes must exist in the backend before these flows can complete successfully. The UI displays API errors rather than pretending data was saved. Existing reports, complaints, and shops screens remain in prototype state until connected to persisted endpoints.
